package com.example.certificatestracker

object ApiKeys {
    const val TWELVEDATA = "c021aeeca93343a7a72eaca2eb62f8e6"
    const val MARKETSTACK = "e1e60f41a11968b889595584e0a6c310"
    const val ALPHAVANTAGE = "35Y3470KIRAJIMIC"
    const val STOCKDATA = "sQyjmDtxzY0xZfT6lDy5M66bQLQaeloE2BJAVybP"
}

